package org.sanketika.shapes;

public interface Shape {
	public double area();
	public double perimeter();

}
