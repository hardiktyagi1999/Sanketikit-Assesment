package org.sanketika.shapes;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       Shape shapes[]=new Shape[3];
       shapes[0]=new Rectangle(10,8);
       shapes[1]=new Square(5);
       shapes[2]=new Circle(6);
       computeProperties(shapes);
    }
    
    public static void computeProperties(Shape shapes[]) {
    	for(Shape s:shapes) {
    		System.out.println(s.getClass().getName());
    		System.out.println("Area : "+s.area());
    		System.out.println("Perimeter : "+s.perimeter());
    		System.out.println("=======================================");
    	}
    }
}
