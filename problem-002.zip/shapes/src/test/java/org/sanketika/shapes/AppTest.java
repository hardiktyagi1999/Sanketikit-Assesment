package org.sanketika.shapes;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    
    @org.junit.jupiter.api.Test
    public void testRectangle()
    {
    	Rectangle r=new Rectangle(5,4);
    	double area=r.area();
    	double perimeter=r.perimeter();
        assertTrue( area==20.0 );
        assertTrue(perimeter==18.0);
    }
    @org.junit.jupiter.api.Test
    public void testSquare()
    {
    	Square r=new Square(5);
    	double area=r.area();
    	double perimeter=r.perimeter();
    	assertTrue( area==25.0 );
        assertTrue(perimeter==20.0);
    }
    @org.junit.jupiter.api.Test
    public void testCircle()
    {
    	Circle r=new Circle(6);
    	double area=r.area();
    	double perimeter=r.perimeter();
    	assertTrue( area==113.09733552923255 );
        assertTrue(perimeter==37.69911184307752);
    }
}
