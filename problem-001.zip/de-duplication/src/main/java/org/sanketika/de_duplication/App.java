package org.sanketika.de_duplication;

import java.util.HashSet;

import org.sanketika.bean.Book;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	HashSet<Book> books=new HashSet<Book>();
    	books.add(new Book("1000","Outliers","Malcom Gladwell"));
    	books.add(new Book("1000","Outliers","Malcom Gladwell"));
    	books.add(new Book("1001","John Grisham","Time to Kill"));
    	for(Book b:books)
    		System.out.println(b);
    	
    }
}
